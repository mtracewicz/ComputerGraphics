#ifndef COLOR_H
#define COLOR_H

class Color
{
private:
    int r,g,b;
    int h,s,v;
public:
    Color(/* args */);
    ~Color();
};
#endif