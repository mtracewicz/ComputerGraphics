#include "Color.h"

Color::Color(/* args */)
{
}

Color::~Color()
{
}
